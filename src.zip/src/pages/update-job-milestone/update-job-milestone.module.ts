import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UpdateJobMilestonePage } from './update-job-milestone';

@NgModule({
  declarations: [
    UpdateJobMilestonePage,
  ],
  imports: [
    IonicPageModule.forChild(UpdateJobMilestonePage),
  ],
})
export class UpdateJobMilestonePageModule {}
