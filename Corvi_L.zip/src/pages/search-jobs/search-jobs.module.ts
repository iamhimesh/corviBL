import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SearchJobsPage } from './search-jobs';

@NgModule({
  declarations: [
    SearchJobsPage,
  ],
  imports: [
    IonicPageModule.forChild(SearchJobsPage),
  ],
})
export class SearchJobsPageModule {}
